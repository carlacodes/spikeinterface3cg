class NotDumpableExtractorError(TypeError):
    """Raised whenever current extractor cannot be dumped"""
