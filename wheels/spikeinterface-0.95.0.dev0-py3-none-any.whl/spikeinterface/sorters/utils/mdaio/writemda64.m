function writemda64(X,fname)
writemda(X,fname,'float64');
end