from typing import List, Union
from pathlib import Path
import warnings

import numpy as np

from probeinterface import Probe, ProbeGroup, write_probeinterface, read_probeinterface, select_axes

from .base import BaseExtractor, BaseSegment
from .core_tools import write_binary_recording, write_memory_recording, write_traces_to_zarr, check_json
from .job_tools import job_keys

from warnings import warn


class BaseRecording(BaseExtractor):
    """
    Abstract class representing several a multichannel timeseries (or block of raw ephys traces).
    Internally handle list of RecordingSegment
    """
    _main_annotations = ['is_filtered']
    _main_properties = ['group', 'location', 'gain_to_uV', 'offset_to_uV']
    _main_features = []  # recording do not handle features

    def __init__(self, sampling_frequency: float, channel_ids: List, dtype):
        BaseExtractor.__init__(self, channel_ids)

        self.is_dumpable = True

        self._sampling_frequency = sampling_frequency
        self._dtype = np.dtype(dtype)

        self._recording_segments: List[BaseRecordingSegment] = []

        # initialize main annotation and properties
        self.annotate(is_filtered=False)

    def __repr__(self):
        clsname = self.__class__.__name__
        nseg = self.get_num_segments()
        nchan = self.get_num_channels()
        sf_khz = self.get_sampling_frequency() / 1000.
        duration = self.get_total_duration()
        txt = f'{clsname}: {nchan} channels - {nseg} segments - {sf_khz:0.1f}kHz - {duration:0.3f}s'
        if 'file_paths' in self._kwargs:
            txt += '\n  file_paths: {}'.format(self._kwargs['file_paths'])
        if 'file_path' in self._kwargs:
            txt += '\n  file_path: {}'.format(self._kwargs['file_path'])
        return txt

    def get_num_segments(self):
        return len(self._recording_segments)

    def add_recording_segment(self, recording_segment):
        # todo: check channel count and sampling frequency
        self._recording_segments.append(recording_segment)
        recording_segment.set_parent_extractor(self)

    def get_sampling_frequency(self):
        return self._sampling_frequency

    @property
    def channel_ids(self):
        return self._main_ids

    def get_channel_ids(self):
        return self._main_ids

    def get_num_channels(self):
        return len(self.get_channel_ids())

    def get_dtype(self):
        return self._dtype

    def get_num_samples(self, segment_index=None):
        segment_index = self._check_segment_index(segment_index)
        return self._recording_segments[segment_index].get_num_samples()

    get_num_frames = get_num_samples

    def get_total_samples(self):
        s = 0
        for segment_index in range(self.get_num_segments()):
            s += self.get_num_samples(segment_index)
        return s

    def get_total_duration(self):
        duration = self.get_total_samples() / self.get_sampling_frequency()
        return duration

    def get_traces(self,
                   segment_index: Union[int, None] = None,
                   start_frame: Union[int, None] = None,
                   end_frame: Union[int, None] = None,
                   channel_ids: Union[List, None] = None,
                   order: Union[str, None] = None,
                   return_scaled=False,
                   ):

        segment_index = self._check_segment_index(segment_index)
        channel_indices = self.ids_to_indices(channel_ids, prefer_slice=True)
        rs = self._recording_segments[segment_index]
        traces = rs.get_traces(start_frame=start_frame, end_frame=end_frame, channel_indices=channel_indices)
        if order is not None:
            assert order in ["C", "F"]
            traces = np.asanyarray(traces, order=order)
        if return_scaled:
            if not self.has_scaled_traces():
                raise ValueError('This recording do not support return_scaled=True (need gain_to_uV and offset_'
                                 'to_uV properties)')
            else:
                gains = self.get_property('gain_to_uV')
                offsets = self.get_property('offset_to_uV')
                gains = gains[channel_indices].astype('float32')
                offsets = offsets[channel_indices].astype('float32')
                traces = traces.astype('float32') * gains + offsets
        return traces

    def has_scaled_traces(self):
        if self.get_property('gain_to_uV') is None or self.get_property('offset_to_uV') is None:
            return False
        else:
            return True

    def is_filtered(self):
        # the is_filtered is handle with annotation
        return self._annotations.get('is_filtered', False)

    def get_times(self, segment_index=None):
        """
        Get time vector for a recording segment.

        If the segment has a time_vector, then it is returned. Otherwise
        a time_vector is constructed on the fly with sampling frequency.
        If t_start is defined and the time vector is constructed on the fly,
        the first time will be t_start. Otherwise it will start from 0.
        """
        segment_index = self._check_segment_index(segment_index)
        rs = self._recording_segments[segment_index]
        times = rs.get_times()
        return times

    def has_time_vector(self, segment_index=None):
        """
        Check if the segment of the recording has a time vector.
        """
        segment_index = self._check_segment_index(segment_index)
        rs = self._recording_segments[segment_index]
        d = rs.get_times_kwargs()
        return d['time_vector'] is not None

    def set_times(self, times, segment_index=None, with_warning=True):
        """
        Set times for a recording segment.
        """
        segment_index = self._check_segment_index(segment_index)
        rs = self._recording_segments[segment_index]

        assert times.ndim == 1, 'Time must have ndim=1'
        assert rs.get_num_samples() == times.shape[0], 'times have wrong shape'

        rs.t_start = None
        rs.time_vector = times.astype('float64')

        if with_warning:
            warnings.warn('Setting times with Recording.set_times() is not recommended because '
                          'times are not always propagated to across preprocessing'
                          'Use use this carefully!')

    def _save(self, format='binary', **save_kwargs):
        """
        This function replaces the old CacheRecordingExtractor, but enables more engines
        for caching a results. At the moment only 'binary' with memmap is supported.
        We plan to add other engines, such as zarr and NWB.
        """

        # handle t_starts
        t_starts = []
        has_time_vectors = []
        for segment_index, rs in enumerate(self._recording_segments):
            d = rs.get_times_kwargs()
            t_starts.append(d['t_start'])
            has_time_vectors.append(d['time_vector'] is not None)

        if all(t_start is None for t_start in t_starts):
            t_starts = None

        if format == 'binary':
            # TODO save properties as npz!!!!!
            folder = save_kwargs['folder']
            file_paths = [folder / f'traces_cached_seg{i}.raw' for i in range(self.get_num_segments())]
            dtype = save_kwargs.get('dtype', None)
            if dtype is None:
                dtype = self.get_dtype()

            job_kwargs = {k: save_kwargs[k] for k in job_keys if k in save_kwargs}
            write_binary_recording(self, file_paths=file_paths, dtype=dtype, **job_kwargs)

            from .binaryrecordingextractor import BinaryRecordingExtractor
            cached = BinaryRecordingExtractor(file_paths=file_paths, sampling_frequency=self.get_sampling_frequency(),
                                              num_chan=self.get_num_channels(), dtype=dtype,
                                              t_starts=t_starts, channel_ids=self.get_channel_ids(), time_axis=0,
                                              file_offset=0, gain_to_uV=self.get_channel_gains(),
                                              offset_to_uV=self.get_channel_offsets())

        elif format == 'memory':
            job_kwargs = {k: save_kwargs[k] for k in job_keys if k in save_kwargs}
            traces_list = write_memory_recording(self, dtype=None, **job_kwargs)
            from .numpyextractors import NumpyRecording

            cached = NumpyRecording(traces_list, self.get_sampling_frequency(), t_starts=t_starts,
                                    channel_ids=self.channel_ids)

        elif format == 'zarr':
            from .zarrrecordingextractor import get_default_zarr_compressor, ZarrRecordingExtractor
            
            zarr_root = save_kwargs.get('zarr_root', None)
            zarr_path = save_kwargs.get('zarr_path', None)

            zarr_root.attrs["sampling_frequency"] = float(self.get_sampling_frequency())
            zarr_root.attrs["num_segments"] = int(self.get_num_segments())
            zarr_root.create_dataset(name="channel_ids", data=self.get_channel_ids(),
                                     compressor=None)

            dataset_paths = [f'traces_seg{i}' for i in range(self.get_num_segments())]
            dtype = save_kwargs.get('dtype', None)
            if dtype is None:
                dtype = self.get_dtype()
            compressor = save_kwargs.get('compressor', None)
            
            if compressor is None:
                compressor = get_default_zarr_compressor()
                print(f"Using default zarr compressor: {compressor}. To use a different compressor, use the "
                      f"'compressor' argument")
            
            filters = save_kwargs.get('filters', None)

            job_kwargs = {k: save_kwargs[k]
                          for k in job_keys if k in save_kwargs}
            write_traces_to_zarr(self, zarr_root=zarr_root, zarr_path=zarr_path, dataset_paths=dataset_paths,
                                 dtype=dtype, compressor=compressor, filters=filters, **job_kwargs)

            # save probe
            if self.get_property('contact_vector') is not None:
                probegroup = self.get_probegroup()
                zarr_root.attrs["probe"] = check_json(probegroup.to_dict(array_as_list=True))

            # save time vector if any
            t_starts = np.zeros(self.get_num_segments(), dtype='float64') * np.nan
            for segment_index, rs in enumerate(self._recording_segments):
                d = rs.get_times_kwargs()
                time_vector = d['time_vector']
                if time_vector is not None:
                    _ = zarr_root.create_dataset(name=f'times_seg{segment_index}', data=time_vector,
                                                 filters=filters,
                                                 compressor=compressor)
                elif d["t_start"] is not None:
                    t_starts[segment_index] = d["t_start"]

            if np.any(~np.isnan(t_starts)):
                zarr_root.create_dataset(name="t_starts", data=t_starts,
                                         compressor=None)

            cached = ZarrRecordingExtractor(zarr_path)

        elif format == 'nwb':
            # TODO implement a format based on zarr
            raise NotImplementedError

        else:
            raise ValueError(f'format {format} not supported')

        if self.get_property('contact_vector') is not None:
            probegroup = self.get_probegroup()
            cached.set_probegroup(probegroup)

        for segment_index, rs in enumerate(self._recording_segments):
            d = rs.get_times_kwargs()
            time_vector = d['time_vector']
            if time_vector is not None:
                cached._recording_segments[segment_index].time_vector = time_vector

        return cached

    def _extra_metadata_from_folder(self, folder):
        # load probe
        folder = Path(folder)
        if (folder / 'probe.json').is_file():
            probegroup = read_probeinterface(folder / 'probe.json')
            self.set_probegroup(probegroup, in_place=True)

        # load time vector if any
        for segment_index, rs in enumerate(self._recording_segments):
            time_file = folder / f'times_cached_seg{segment_index}.npy'
            if time_file.is_file():
                time_vector = np.load(time_file)
                rs.time_vector = time_vector

    def _extra_metadata_to_folder(self, folder):
        # save probe
        if self.get_property('contact_vector') is not None:
            probegroup = self.get_probegroup()
            write_probeinterface(folder / 'probe.json', probegroup)

        # save time vector if any
        for segment_index, rs in enumerate(self._recording_segments):
            d = rs.get_times_kwargs()
            time_vector = d['time_vector']
            if time_vector is not None:
                np.save(folder / f'times_cached_seg{segment_index}.npy', time_vector)

    # def _extra_metadata_to_zarr(self, zarr_root, compressor, filters):
    #     # save probe
    #     if self.get_property('contact_vector') is not None:
    #         probegroup = self.get_probegroup()
    #         zarr_root.attrs["probe"] = probegroup.to_dict()

    #     # save time vector if any
    #     for segment_index, rs in enumerate(self._recording_segments):
    #         d = rs.get_times_kwargs()
    #         time_vector = d['time_vector']
    #         if time_vector is not None:
    #             z = zarr_root.create_dataset(name=f'times_seg{segment_index}', data=time_vector,
    #                                          chunks=(chunk_size, None), dtype=dtype,
    #                                          filters=filters,
    #                                          compressor=compressor)
    #             np.save(folder / f'times_cached_seg{segment_index}.npy', time_vector)

    def set_probe(self, probe, group_mode='by_probe', in_place=False):
        """
        Wrapper on top on set_probes when there one unique probe.
        """
        assert isinstance(probe, Probe), 'must give Probe'
        probegroup = ProbeGroup()
        probegroup.add_probe(probe)
        return self.set_probes(probegroup, group_mode=group_mode, in_place=in_place)

    def set_probegroup(self, probegroup, group_mode='by_probe', in_place=False):
        return self.set_probes(probegroup, group_mode=group_mode, in_place=in_place)

    def set_probes(self, probe_or_probegroup, group_mode='by_probe', in_place=False):
        """
        Attach a Probe to a recording.
        For this Probe.device_channel_indices is used to link contacts to recording channels.
        If some contacts of the Probe are not connected (device_channel_indices=-1)
        then the recording is "sliced" and only connected channel are kept.

        The probe order is not kept. Channel ids are re-ordered to match the channel_ids of the recording.


        Parameters
        ----------
        probe_or_probegroup: Probe, list of Probe, or ProbeGroup
            The probe(s) to be attached to the recording
        group_mode: str
            'by_probe' or 'by_shank'. Adds grouping property to the recording based on the probes ('by_probe')
            or  shanks ('by_shanks')
        in_place: bool
            False by default.
            Useful internally when extractor do self.set_probegroup(probe)

        Returns
        -------
        sub_recording: BaseRecording
            A view of the recording (ChannelSliceRecording or clone or itself)
        """
        from spikeinterface import ChannelSliceRecording

        assert group_mode in ('by_probe', 'by_shank'), "'group_mode' can be 'by_probe' or 'by_shank'"

        # handle several input possibilities
        if isinstance(probe_or_probegroup, Probe):
            probegroup = ProbeGroup()
            probegroup.add_probe(probe_or_probegroup)
        elif isinstance(probe_or_probegroup, ProbeGroup):
            probegroup = probe_or_probegroup
        elif isinstance(probe_or_probegroup, list):
            assert all([isinstance(e, Probe) for e in probe_or_probegroup])
            probegroup = ProbeGroup()
            for probe in probe_or_probegroup:
                probegroup.add_probe(probe)
        else:
            raise ValueError('must give Probe or ProbeGroup or list of Probe')

        # handle not connected channels
        assert all(probe.device_channel_indices is not None for probe in probegroup.probes), \
            'Probe must have device_channel_indices'

        # this is a vector with complex fileds (dataframe like) that handle all contact attr
        arr = probegroup.to_numpy(complete=True)

        # keep only connected contact ( != -1)
        keep = arr['device_channel_indices'] >= 0
        if np.any(~keep):
            warn('The given probes have unconnected contacts: they are removed')

        arr = arr[keep]
        inds = arr['device_channel_indices']
        order = np.argsort(inds)
        inds = inds[order]
        # check
        if np.max(inds) >= self.get_num_channels():
            raise ValueError('The given Probe have "device_channel_indices" that do not match channel count')
        new_channel_ids = self.get_channel_ids()[inds]
        arr = arr[order]
        arr['device_channel_indices'] = np.arange(arr.size, dtype='int64')

        # create recording : channel slice or clone or self
        if in_place:
            if not np.array_equal(new_channel_ids, self.get_channel_ids()):
                raise Exception('set_proce(inplace=True) must have all channel indices')
            sub_recording = self
        else:
            if np.array_equal(new_channel_ids, self.get_channel_ids()):
                sub_recording = self.clone()
            else:
                sub_recording = ChannelSliceRecording(self, new_channel_ids)

        # create a vector that handle all contacts in property
        sub_recording.set_property('contact_vector', arr, ids=None)

        # planar_contour is saved in annotations
        for probe_index, probe in enumerate(probegroup.probes):
            contour = probe.probe_planar_contour
            if contour is not None:
                sub_recording.set_annotation(f'probe_{probe_index}_planar_contour', contour, overwrite=True)

        # duplicate positions to "locations" property
        ndim = probegroup.ndim
        locations = np.zeros((arr.size, ndim), dtype='float64')
        for i, dim in enumerate(['x', 'y', 'z'][:ndim]):
            locations[:, i] = arr[dim]
        sub_recording.set_property('location', locations, ids=None)

        # handle groups
        groups = np.zeros(arr.size, dtype='int64')
        if group_mode == 'by_probe':
            for group, probe_index in enumerate(np.unique(arr['probe_index'])):
                mask = arr['probe_index'] == probe_index
                groups[mask] = group
        elif group_mode == 'by_shank':
            assert all(probe.shank_ids is not None for probe in probegroup.probes), \
                'shank_ids is None in probe, you cannot group by shank'
            for group, a in enumerate(np.unique(arr[['probe_index', 'shank_ids']])):
                mask = (arr['probe_index'] == a['probe_index']) & (arr['shank_ids'] == a['shank_ids'])
                groups[mask] = group
        sub_recording.set_property('group', groups, ids=None)

        return sub_recording

    def get_probe(self):
        probes = self.get_probes()
        assert len(probes) == 1, 'there are several probe use .get_probes() or get_probegroup()'
        return probes[0]

    def get_probes(self):
        probegroup = self.get_probegroup()
        return probegroup.probes

    def get_probegroup(self):
        arr = self.get_property('contact_vector')
        if arr is None:
            positions = self.get_property('location')
            if positions is None:
                raise ValueError('There is not Probe attached to recording. use set_probe(...)')
            else:
                warn('There is no Probe attached to this recording. Creating a dummy one with contact positions')
                ndim = positions.shape[1]
                probe = Probe(ndim=ndim)
                probe.set_contacts(positions=positions, shapes='circle', shape_params={'radius': 5})
                probe.set_device_channel_indices(np.arange(self.get_num_channels(), dtype='int64'))
                #  probe.create_auto_shape()
                probegroup = ProbeGroup()
                probegroup.add_probe(probe)
        else:
            probegroup = ProbeGroup.from_numpy(arr)
            for probe_index, probe in enumerate(probegroup.probes):
                contour = self.get_annotation(f'probe_{probe_index}_planar_contour')
                if contour is not None:
                    probe.set_planar_contour(contour)
        return probegroup

    def set_dummy_probe_from_locations(self, locations, shape="circle", shape_params={"radius": 1},
                                       axes="xy"):
        """
        Sets a 'dummy' probe based on locations.

        Parameters
        ----------
        locations : np.array
            Array with channel locations (num_channels, ndim) [ndim can be 2 or 3]
        shape : str, optional
            Electrode shapes, by default "circle"
        shape_params : dict, optional
            Shape parameters, by default {"radius": 1}
        axes : str, optional
            If ndim is 3, indicates the axes that define the plane of the electrodes, by default "xy"
        """
        ndim = locations.shape[1]
        probe = Probe(ndim=2)
        if ndim == 3:
            locations_2d = select_axes(locations, axes)
        else:
            locations_2d = locations
        probe.set_contacts(locations_2d, shapes=shape, shape_params=shape_params)
        probe.set_device_channel_indices(np.arange(self.get_num_channels()))

        if ndim == 3:
            probe = probe.to_3d(axes=axes)

        self.set_probe(probe, in_place=True)

    def set_channel_locations(self, locations, channel_ids=None):
        if self.get_property('contact_vector') is not None:
            raise ValueError('set_channel_locations(..) destroy the probe description, prefer set_probes(..)')
        self.set_property('location', locations, ids=channel_ids)

    def get_channel_locations(self, channel_ids=None, axes: str = 'xy'):
        if channel_ids is None:
            channel_ids = self.get_channel_ids()
        channel_indices = self.ids_to_indices(channel_ids)
        if self.get_property('contact_vector') is not None:
            if len(self.get_probes()) == 1:
                probe = self.get_probe()
                positions = probe.contact_positions[channel_indices]
            else:
                # check that multiple probes are non-overlapping
                all_probes = self.get_probes()
                all_positions = []
                for i in range(len(all_probes)):
                    probe_i = all_probes[i]
                    # check that all positions in probe_j are outside probe_i boundaries
                    x_bounds_i = [np.min(probe_i.contact_positions[:, 0]),
                                  np.max(probe_i.contact_positions[:, 0])]
                    y_bounds_i = [np.min(probe_i.contact_positions[:, 1]),
                                  np.max(probe_i.contact_positions[:, 1])]

                    for j in range(i + 1, len(all_probes)):
                        probe_j = all_probes[j]

                        if np.any(np.array([x_bounds_i[0] < cp[0] < x_bounds_i[1] and 
                                            y_bounds_i[0] < cp[1] < y_bounds_i[1]
                                            for cp in probe_j.contact_positions])):
                            raise Exception("Probes are overlapping! Retrieve locations of single probes separately")
                all_positions = np.vstack([probe.contact_positions for probe in all_probes])
                positions = all_positions[channel_indices]
            return select_axes(positions, axes)
        else:
            locations = self.get_property('location')
            if locations is None:
                raise Exception('There are no channel locations')
            locations = np.asarray(locations)[channel_indices]
            return select_axes(locations, axes)

    def has_3d_locations(self):
        return self.get_property('location').shape[1] == 3

    def clear_channel_locations(self, channel_ids=None):
        if channel_ids is None:
            n = self.get_num_channel()
        else:
            n = len(channel_ids)
        locations = np.zeros((n, 2)) * np.nan
        self.set_property('location', locations, ids=channel_ids)

    def set_channel_groups(self, groups, channel_ids=None):
        if 'probes' in self._annotations:
            warn('set_channel_groups() destroys the probe description. Using set_probe() is preferable')
            self._annotations.pop('probes')
        self.set_property('group', groups, ids=channel_ids)

    def get_channel_groups(self, channel_ids=None):
        groups = self.get_property('group', ids=channel_ids)
        return groups

    def clear_channel_groups(self, channel_ids=None):
        if channel_ids is None:
            n = self.get_num_channels()
        else:
            n = len(channel_ids)
        groups = np.zeros(n, dtype='int64')
        self.set_property('group', groups, ids=channel_ids)

    def set_channel_gains(self, gains, channel_ids=None):
        if np.isscalar(gains):
            gains = [gains] * self.get_num_channels()
        self.set_property('gain_to_uV', gains, ids=channel_ids)

    def get_channel_gains(self, channel_ids=None):
        return self.get_property('gain_to_uV', ids=channel_ids)

    def set_channel_offsets(self, offsets, channel_ids=None):
        if np.isscalar(offsets):
            offsets = [offsets] * self.get_num_channels()
        self.set_property('offset_to_uV', offsets, ids=channel_ids)

    def get_channel_offsets(self, channel_ids=None):
        return self.get_property('offset_to_uV', ids=channel_ids)

    def get_channel_property(self, channel_id, key):
        values = self.get_property(key)
        v = values[self.id_to_index(channel_id)]
        return v

    def channel_slice(self, channel_ids, renamed_channel_ids=None):
        from spikeinterface import ChannelSliceRecording
        sub_recording = ChannelSliceRecording(self, channel_ids, renamed_channel_ids=renamed_channel_ids)
        return sub_recording
    
    def remove_channels(self, remove_channel_ids):
        from spikeinterface import ChannelSliceRecording
        new_channel_ids = self.channel_ids[~np.in1d(self.channel_ids, removed_channel_ids)]
        sub_recording = ChannelSliceRecording(self, new_channel_ids)
        return sub_recording

    def frame_slice(self, start_frame, end_frame):
        from spikeinterface import FrameSliceRecording
        sub_recording = FrameSliceRecording(self, start_frame=start_frame, end_frame=end_frame)
        return sub_recording

    def split_by(self, property='group', outputs='dict'):
        assert outputs in ('list', 'dict')
        from .channelslicerecording import ChannelSliceRecording
        values = self.get_property(property)
        if values is None:
            raise ValueError(f'property {property} is not set')

        if outputs == 'list':
            recordings = []
        elif outputs == 'dict':
            recordings = {}
        for value in np.unique(values):
            inds, = np.nonzero(values == value)
            new_channel_ids = self.get_channel_ids()[inds]
            subrec = ChannelSliceRecording(self, new_channel_ids)
            if outputs == 'list':
                recordings.append(subrec)
            elif outputs == 'dict':
                recordings[value] = subrec
        return recordings
    
    def select_segments(self, segment_indices):
        """
        Return a recording with the segments specified by 'segment_indices'

        Parameters
        ----------
        segment_indices : list of int
            List of segment indices to keep in the returned recording

        Returns
        -------
        SelectSegmentRecording
            The recording with the selected segments
        """
        from .segmentutils import SelectSegmentRecording
        return SelectSegmentRecording(self, segment_indices=segment_indices)

    def planarize(self, axes: str = "xy"):
        """
        Returns a Recording with a 2D probe from one with a 3D probe

        Parameters
        ----------
        axes : str, optional
            The axes to keep, by default "xy"

        Returns
        -------
        BaseRecording
            The recording with 2D positions
        """
        assert self.has_3d_locations, "The 'planarize' function needs a recording with 3d locations"
        assert len(axes) == 2, "You need to specify 2 dimensions (e.g. 'xy', 'zy')"

        probe2d = self.get_probe().to_2d(axes=axes)
        recording2d = self.clone()
        recording2d.set_probe(probe2d, in_place=True)

        return recording2d


class BaseRecordingSegment(BaseSegment):
    """
    Abstract class representing a multichannel timeseries, or block of raw ephys traces
    """

    def __init__(self, sampling_frequency=None, t_start=None, time_vector=None):
        # sampling_frequency and time_vector are exclusive
        if sampling_frequency is None:
            assert time_vector is not None, "Pass either 'sampling_frequency' or 'time_vector'"
            assert time_vector.ndim == 1, "time_vector should be a 1D array"

        if time_vector is None:
            assert sampling_frequency is not None, "Pass either 'sampling_frequency' or 'time_vector'"

        self.sampling_frequency = sampling_frequency
        self.t_start = t_start
        self.time_vector = time_vector

        BaseSegment.__init__(self)

    def get_times(self):
        if self.time_vector is not None:
            if isinstance(self.time_vector, np.ndarray):
                return self.time_vector
            else:
                return np.array(self.time_vector)
        else:
            time_vector = np.arange(self.get_num_samples(), dtype='float64')
            time_vector /= self.sampling_frequency
            if self.t_start is not None:
                time_vector += self.t_start
            return time_vector

    def get_times_kwargs(self):
        # useful for other internal RecordingSegment
        d = dict(sampling_frequency=self.sampling_frequency, t_start=self.t_start,
                 time_vector=self.time_vector)
        return d

    def sample_index_to_time(self, sample_ind):
        """
        Transform sample index into time in seconds
        """
        if self.time_vector is None:
            time_s = sample_ind / self.sampling_frequency
            if self.t_start is not None:
                time_s += self.t_start
        else:
            time_s = self.time_vector[sample_ind]
        return time_s

    def time_to_sample_index(self, time_s):
        """
        Transform time in seconds into sample index
        """
        if self.time_vector is None:
            if self.t_start is None:
                sample_index = time_s * self.sampling_frequency
            else:
                sample_index = (time_s - self.t_start) * self.sampling_frequency
        else:
            sample_index = np.searchsorted(self.time_vector, time_s, side='right') - 1
        return int(sample_index)

    def get_num_samples(self) -> int:
        """Returns the number of samples in this signal segment

        Returns:
            SampleIndex: Number of samples in the signal segment
        """
        # must be implemented in subclass
        raise NotImplementedError

    def get_traces(self,
                   start_frame: Union[int, None] = None,
                   end_frame: Union[int, None] = None,
                   channel_indices: Union[List, None] = None,
                   ) -> np.ndarray:
        """
        Return the raw traces, optionally for a subset of samples and/or channels

        Parameters
        ----------
        start_frame: (Union[int, None], optional)
            start sample index, or zero if None. Defaults to None.
        end_frame: (Union[int, None], optional)
            end_sample, or number of samples if None. Defaults to None.
        channel_indices: (Union[List, None], optional)
            Indices of channels to return, or all channels if None. Defaults to None.
        order: (Order, optional)
            The memory order of the returned array.
            Use Order.C for C order, Order.F for Fortran order, or Order.K to keep the order of the underlying data.
            Defaults to Order.K.

        Returns
        -------
        traces: np.ndarray
            Array of traces, num_samples x num_channels
        """
        # must be implemented in subclass
        raise NotImplementedError
