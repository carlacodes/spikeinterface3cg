from neo.io.basefromrawio import BaseFromRaw
from neo.rawio.customtdtrawio import CustomTdtRawIO


class CustomTdtIO(CustomTdtRawIO, BaseFromRaw):
    name = 'Tdt IO'
    description = "Tdt IO"
    mode = 'dir'

    def __init__(self, dirname,store=None):
        CustomTdtRawIO.__init__(self, dirname=dirname, store=store)
        BaseFromRaw.__init__(self, dirname)
