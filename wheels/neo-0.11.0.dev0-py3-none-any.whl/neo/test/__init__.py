"""
The subdirectory coretest contains tests for neo.core

The subdirectory iotest contains tests for neo.io
"""
