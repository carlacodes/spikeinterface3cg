"""
Contains tests for neo.core
"""
