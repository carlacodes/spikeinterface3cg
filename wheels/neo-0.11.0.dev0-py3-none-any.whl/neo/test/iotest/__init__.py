"""
Contains tests for neo.io
"""
