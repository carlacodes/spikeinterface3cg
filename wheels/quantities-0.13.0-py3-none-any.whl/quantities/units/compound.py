"""
"""

from ..unitquantity import CompoundUnit

pc_per_cc = CompoundUnit("pc/cm**3")
